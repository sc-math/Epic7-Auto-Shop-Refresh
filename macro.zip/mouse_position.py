import time
import pyautogui

time.sleep(1)
print(pyautogui.position())
time.sleep(2)
print(pyautogui.position())